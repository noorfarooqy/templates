RentUP - Responsive Real Estate HTML Template
--------------------------

Thank you for buying the RentUP - Real Estate HTML Template!

You will find the help files inside the "_documentation" folder.

If you need further assistance feel free to contact Themez Hub on the profile page: http://themeforest.net/user/themezhub

If you like this template, please consider giving it a comment and/or a rating!

Notice: This theme was not developed to serve as a content publishing theme. It lacks post styling, commenting features, proper SEO coding for posts and many other features. Its only functionality was meant to be either a Mobile App Template.

Thank you once again,

The Themez Hub team

Version: 1.0
Release date: 10 Aug 2021